****** Copyright ******

This theme item is entirely licensed under the General Public License(GPL). 



****** Changelog ******


= 1.6 =

March 15, 2017

* Compatible with low version PHP (5.3+)
* Fixed some minor errors in the low version of PHP.
* Optimized mobile navigation.



= 1.5 =

December 28, 2016

* Optimized for shortcodes.
* Improved the running speed.
* WordPress 4.7 compatible.


= 1.1 =

October 17, 2016

* Optimized for tablet display


= 1.0 =

September 8, 2016

* Initial version
