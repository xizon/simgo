=== Simgo ===
Contributors: uiuxlab
Requires at least: WordPress 4.5
Tested up to: WordPress 4.7.3
Version: 1.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: custom-menu, editor-style, featured-images, one-column, two-columns, theme-options, translation-ready, post-formats,  custom-background, custom-colors, custom-header, rtl-language-support

== Description ==
A simple blog & portfolio WordPress theme. It is fast and easy switching simply by clicking a mouse. Backstage as a whole is able to customize easily. Finally, put a shortcode anywhere you like, even outside of all. Simgo can be used for portfolio, blog, personal website.



* Custom Slides and Header Background Color.
* Fully responsive, allowing visitors to access your site on any device, from mobile to desktop.
* Infinite Scrolling Support
* Header Custom
* 26+ Shortcodes Support
* Easy Theme Options
* Page templates are included with the theme for additional layout options. In addition, Natural features a social media menu, a slideshow, footer widgets, and more.
* Make an impact with a full-width slider that stretches to the edges of the screen — or use the contemporary carousel-style slider.
* Affinity supports prominent Featured Images on the blog, and single posts and pages.
* 6 Post Formats
* 600+ Google Fonts for slider
* Supports a handy Social Links menu, which appears in the footer.
* The GPL v2.0 or later license. :) Use it to make something cool.

For more information about Simgo please go to https://uiux.cc


== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in Simgo in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
4. Go to https://codex.wordpress.org/Twenty_Sixteen for a guide on how to customize this theme.
5. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Copyright ==

Simgo WordPress Theme, Copyright 2014-2015 WordPress.org
Simgo is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


Simgo Theme bundles the following third-party resources:


Font Awesome v4.5
Licenses: MIT
Source: http://fontawesome.io/


TGM Plugin Activation
Source:  http://tgmpluginactivation.com/
Licenses: GPLv2 or later


jQuery FlexSlider v2.6.2
Licenses: GPLv2 or later
Source: http://www.woothemes.com/flexslider


Kirki
Licenses: MIT
Source: https://wordpress.org/plugins/kirki/


Uix Shortcodes
Licenses: GPLv2 or later
Source: https://wordpress.org/plugins/uix-shortcodes/


Uix Slides
Licenses: GPLv2 or later
Source: https://github.com/xizon/Uix-Slides/


modernizr
Licenses: MIT
Source: https://modernizr.com/


Respond.js
Licenses: MIT
Source: https://github.com/scottjehl/Respond



All photos uploaded to the site are released under Creative Commons - CC0 and do not require attribution. No more hassle trying to figure out whether you can use photos for commercial use and whether you need to provide attribution. (http://www.gratisography.com, https://stocksnap.io ) Part of the image and videos used in the demo are not distributed with the theme. They are all licensed under Creative Commons and credited to their respective creator/owner.


== Changelog ==


= 1.7 =

March 26, 2017

* Optimized admin panel.
* Upgraded shortcodes plugin.



= 1.6 =

* Compatible with low version PHP (5.3+)
* Fixed some minor errors in the low version of PHP.
* Optimized mobile navigation.

 

= 1.5 =

* Optimized for shortcodes.
* Optimized for slideshow.
* Improved the running speed.
* WordPress 4.7 compatible.

 

= 1.1 =

* Optimized for tablet display

 

= 1.0 =

* Initial version