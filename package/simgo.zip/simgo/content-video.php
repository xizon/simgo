<?php
/**
 * The template for displaying posts in the Video post format
 * 
 */

$video = get_post_meta( get_the_ID(), 'cus_post_ex_video', true );


if ( is_singular() ) { 
/* ==================  single ==================  */  
?>
    

    <?php if ( !empty( $video ) ) { ?>
        <div class="post-video">
                <?php echo wp_oembed_get( $video ); ?>
        </div>
    <?php } ?>
    
<?php 
/* ==================  /single ==================  */ 


} else { 
/* ==================  loop ==================  */  

    $post_class = implode(' ',get_post_class( 'infinite-scroll-list', $post->ID ) );
?>


    <div class="infinite-scroll-list post-list"> 
    
        
        <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    
                <!-- //// -->
                <h3 class="entry-title"><i class="fa fa-video-camera"></i>&nbsp;<a href="<?php echo esc_url( get_permalink() );?>" title="<?php echo esc_attr( get_the_title() ); ?>">
                  <?php the_title();?>
                  </a>
                </h3>
                
                
                <!-- //// -->
                
                
			   <?php
               
               if ( !empty( $video ) ) {
                   echo '<div class="post-video">'.wp_oembed_get( $video, array( 'width'=>644, 'height'=>437 ) ).'</div>';
               } else {
				   $value = Simgo_Core::get_first_video();
                   if ( !empty( $value ) ) echo '<div class="post-video">'.$value.'</div>';
               }
            
               ?>
             
            
                <!-- //// -->
                <?php
                get_template_part( 'partials', 'common_entries' );
                
                ?>
                
         </div><!-- #post-## -->
        
    </div>


<?php 
/* ==================  /loop ==================  */ 
} 
?>
